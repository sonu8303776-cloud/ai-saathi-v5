# AI Saathi V4

## V4 में क्या है
- Hindi + Hinglish natural conversation
- User के time और earning target को context में लेना
- Role-based 3 daily missions
- Mission progress
- Local profile/history
- Browser Hindi voice output
- Real OpenAI Responses API backend
- API key frontend में नहीं रखी गई है
- API unavailable होने पर basic offline fallback

## चलाने का तरीका
1. Node.js install करें.
2. इस folder में terminal खोलें.
3. `npm install`
4. `.env.example` को `.env` नाम दें और उसमें अपनी OpenAI API key डालें.
5. `npm start`
6. Browser में `http://localhost:3000` खोलें.

महत्वपूर्ण: API key को `index.html` में कभी न डालें. Server-side environment variable में रखें.
